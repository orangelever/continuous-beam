clc;
clear;
%--------initial--------%
E=3e4;
NU=1/4;
t=0.1;
ID=1;
%----------meshblock---------%
l=10;x=3;Le=0.5;xe=0.5;  
[e,nn,location]=meshblock(l,x,Le,xe);
dir=dir_trans(l,x,Le,xe);
%-----------stiffness matrix------------%
[temp_a,temp_b]=size(e);
KK=zeros(2*nn);
for i=1:temp_a
k(:,:,i)=Triangle2D3Node_Stiffness(E,NU,t,e(i,1),e(i,2),e(i,3),e(i,4),e(i,5),e(i,6),ID);
end
%------------assembly----------------------------%
for i=1:temp_a
KK=Triangle2D3Node_Assembly(KK,k(:,:,i),dir(i,1),dir(i,2),dir(i,3));
end
%---------load---------------------------------%
F=input('please input the magnitude of the concentrated force:\n');
F_x=input('please input the location of the concentrated force(should be int):\n');
p=zeros(2*nn,1);
p(2*(nn-(l-F_x)/Le),1)=F;
%-------------boundary condition---------------------------------%
link=[1];
hinge=[1+l/2/Le,l/Le+1];
for i=1:length(link)
    KK(2*link(i),:)=zeros(1,length(KK(1,:)));
    KK(2*link(i),2*link(i))=1;
end
for i=1:length(hinge)
    KK(2*hinge(i),:)=zeros(1,length(KK(1,:)));
    KK(2*hinge(i),2*hinge(i))=1;
    KK(2*hinge(i)-1,:)=zeros(1,length(KK(1,:)));
    KK(2*hinge(i)-1,2*hinge(i)-1)=1;
end

%----------------solve----------------%
u=KK\p;
for i=1:nn
    u1(i,:)=[u(2*i-1),u(2*i)];
end
figure(2)
for i=1:nn
    scatter(location(i,1),location(i,2),'r');
    scatter(location(i,1)+u1(i,1),location(i,2)+u1(i,2),'b');
    text(location(i,1),location(i,2)+0.1,num2str(i));
    text(location(i,1)+u1(i,1),location(i,2)+u1(i,2)+0.1,num2str(i));
    hold on
    axis equal
    axis off
end
%-----------��Ӧ��Ӧ�䲢������ͼ-------------%
U=u;
P=KK*U;
for i=1:temp_a
um=[U(2*dir(i,1)-1);U(2*dir(i,1));U(2*dir(i,2)-1);U(2*dir(i,2));U(2*dir(i,3)-1);U(2*dir(i,3))];
xi(i)=location(dir(i,1),1);dxi(i)=u1(dir(i,1),1);
yi(i)=location(dir(i,1),2);dyi(i)=u1(dir(i,1),2);
xj(i)=location(dir(i,2),1);dxj(i)=u1(dir(i,2),1);
yj(i)=location(dir(i,2),2);dyj(i)=u1(dir(i,2),2);
xm(i)=location(dir(i,3),1);dxm(i)=u1(dir(i,3),1);
ym(i)=location(dir(i,3),2);dym(i)=u1(dir(i,3),2);
strain(i,:)=Triangle2D3Node_Strain(xi(i),yi(i),xj(i),yj(i),xm(i),ym(i),um);
stress(i,:)=Triangle2D3Node_Stress(E,NU,xi(i),yi(i),xj(i),yj(i),xm(i),ym(i),um,ID);
end
figure(3)
x0=[xi;xj;xm];
y0=[yi;yj;ym];
c=stress(:,2);
patch(x0,y0,c);
axis equal
colormap hot
colorbar
figure(4)
c=strain(:,2);
patch(x0,y0,c);
axis equal
colorbar
colormap hot
figure(5)
x0=[xi+dxi;xj+dxj;xm+dxm];
y0=[yi+dyi;yj+dyj;ym+dym];
c=zeros(1,temp_a);
patch(x0,y0,c);
axis equal
min(strain(:,2))


