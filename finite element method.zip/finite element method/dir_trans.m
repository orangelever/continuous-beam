function dir = dir_trans( l,x,le,xe )
%DIR_TRANS ���䷽������
nl=l/le; nx=x/xe; n=nl*nx;nn=(nl+1)*(nx+1);
dir=zeros(n*2,3);
for i=1:nx
    for j=1:nl
    dir(2*(j+(i-1)*nl)-1,:)=[j+(i-1)*(nl+1),j+(i-1)*(nl+1)+1,j+(i)*(nl+1)];
    dir(2*(j+(i-1)*nl),:)=[j+(i)*(nl+1)+1,j+(i)*(nl+1),j+(i)*(nl+1)-nl];
    end
end
end

