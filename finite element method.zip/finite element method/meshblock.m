function [ele_location,nn,location] = meshblock(l,x,le,xe)
%MESHBLOCK ��Ԫ����
%   ����ʵ��ĳ����뵥Ԫ�Ĵ�С�������Ԫ�ڵ������
nl=l/le; nx=x/xe; n=nl*nx;nn=(nl+1)*(nx+1);
location=zeros(nn,2);
for i=1:(nx+1)
    for j=1:(nl+1)
    location(j+(i-1)*(nl+1),:)=[(j-1)*le,(i-1)*xe];
    end
end
% constitute the direction vector
dir=zeros(n*2,3);
for i=1:nx
    for j=1:nl
    dir(2*(j+(i-1)*nl)-1,:)=[j+(i-1)*(nl+1),j+(i-1)*(nl+1)+1,j+(i)*(nl+1)];
    dir(2*(j+(i-1)*nl),:)=[j+(i)*(nl+1)+1,j+(i)*(nl+1),j+(i)*(nl+1)-nl];
    end
end
%assenmble the element_node_location matrix
ele_location=zeros(n*2,6);
for i=1:2*n
    ele_location(i,:)=[location(dir(i,1),:),location(dir(i,2),:),location(dir(i,3),:)];
end
% plot
figure(1)
for i=1:nn
scatter(location(i,1),location(i,2));
text(location(i,1),location(i,2)+0.3,num2str(i));
hold on
axis equal
axis off
end
end

